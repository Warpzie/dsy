<?php



?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Document</title>
</head>
<body id="bg">
            <form action= "#" method="POST" id="mailForm">
                <fieldset id="f">
                    <div id="title">
                        Feedback Form
                    </div>
                        <div class="inbox">
                        <label for="Name" class="formLabel">Name:</label><br>
                        <input type = "text" name = "Name" class="input" placeholder="Enter name">
                    </div>
                    <div class="inbox">
                        <label for="Email" class="formLabel">Email:</label><br>
                        <input type = "text" name = "Email" class="input" placeholder="Enter email">
                    </div>
                    <div class="inbox">
                        <label for="Subject" class="formLabel">Subject:</label><br>
                        <input type = "text" name = "Suvject" class="input" placeholder="Enter subject">
                    </div>
                    <div class="inbox">
                        <label for="Message" class="formLabel">Message:</label><br>
                        <input type = "textarea" name = "Message" class="inputTxt" placeholder="Enter message" >
                    </div>
                        <input type="button" value="Submit" id="button">
                </fieldset>
            </form>
</body>
</html>