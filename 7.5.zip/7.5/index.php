<?php
//    $cislo1=$_GET['cislo1'];
//    $cislo2=$_GET['cislo2'];
//    echo $cislo1+$cislo2;
?>
