<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = isset($_POST['name']) ? htmlspecialchars(trim($_POST['name'])) : '';
    $username = isset($_POST['username']) ? htmlspecialchars(trim($_POST['username'])) : '';
    $email = isset($_POST['email']) ? htmlspecialchars(trim($_POST['email'])) : '';
    $password = isset($_POST['password']) ? htmlspecialchars(trim($_POST['password'])) : '';
    $passwordRepeat = isset($_POST['passwordRepeat']) ? htmlspecialchars(trim($_POST['passwordRepeat'])) : '';
    $gender = isset($_POST['gender']) ? htmlspecialchars(trim($_POST['gender'])) : '';

    $errors = [];
    if (empty($name)) {
        $errors[] = "name is required.";
    }
    if (empty($username)) {
        $errors[] = "username is required.";
    }
    if (empty($email)) {
        $errors[] = "Email is required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Email is not valid.";
    }
    if (empty($password)) {
        $errors[] = "password is required.";
    }
    if ($password !== $passwordRepeat) {
        $errors[] = "passwords do not match.";
    }
    if (empty($gender)) {
        $errors[] = "gender is required.";
    }
    if (empty($errors)) {
        echo "<p style='color: green;'>success</p>";
    } else {
        foreach ($errors as $error) {
            echo "<p style='color: red;'>$error</p>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Document</title>
</head>
<body>
    <div id="window">
        <div id="leftWin">
            <div id="logo">
                <img src="logo.png" id="logoImg">
            </div>
            <div id="leftBlock">
                <div id="text">
                    <div id="t1">
                        Welcome to SPSIT
                    </div>
                    <div id="t2">
                        Are you ready to join the elite?
                    </div>
                </div>
                <div id="logos">
                    <i class="fa fa-globe" aria-hidden="true"></i>
                    <i class="fa fa-behance" aria-hidden="true"></i>
                    <i class="fa fa-github" aria-hidden="true"></i>
                    <i class="fa fa-twitter" aria-hidden="true"></i>
                </div>
            </div>
        </div>
        <div id="rightWin">
            <form action= "#" method="POST" id="mailForm" >
                <div class="inbox">
                    <label for="name">NAME</label><br>
                    <input type = "text" name = "name" class="input" placeholder="James Bond" require>
                </div>
                <div class="inbox">
                    <label for="username">USERNAME</label><br>
                    <input type = "text" name = "username" class="input" placeholder="james.bond" required>
                </div>
                <div class="inbox">
                    <label for="email">EMAIL</label><br>
                    <input type="email" name = "email" class="input" placeholder="james.bond@spectre.com" required>
                </div>
                <div class="inbox">
                    <label for="password">PASSWORD</label><br>
                    <input type="password" class="input" name="password" placeholder="&#9679;&#9679;&#9679;&#9679;&#9679;&#9679;&#9679;&#9679;" required>
                </div>
                <div class="inbox">
                    <label for="passwordRepeat">REPEAT PASSWORD</label><br>
                    <input type="password" class="input" name="passwordRepeat" placeholder="&#9679;&#9679;&#9679;&#9679;&#9679;&#9679;&#9679;&#9679;" required>
                </div>
                <div class="radio">
                    <label for="gender">GENDER</label>
                    <div id="radioOpt">
                        <div>
                        <input type="radio" name="gender" value="female" required>
                        <label for="gender">FEMALE</label>
                        </div>
                        <div>
                        <input type="radio" name="gender" value="male" required> 
                        <label for="gender">MALE</label>
                        </div>
                    </div>
                </div>
                <div id="bottomDiv">
                    <input type="submit" value="REGISTER" id="regButton">
                    <a href="" id="member">
                        I am already a member    
                    </a>
                </div>
            </form>
        </div>
    </div>
    
</body>
</html>
