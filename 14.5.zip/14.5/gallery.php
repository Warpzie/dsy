<?php include 'includes/header.php'; ?>
<main>
            <h1>
                Gallery
            </h1>
            <p class="content">
                Lorem ipsum dolor, sit amet consectetur adipisicing elit. 
                Sapiente eligendi incidunt iusto natus architecto ratione 
                amet quasi quisquam vero quibusdam et ut, nesciunt corrupti 
                eius accusamus atque dignissimos quos exercitationem.
            </p>
            <p class="content">
                Lorem ipsum dolor, sit amet consectetur adipisicing elit. 
                Sapiente eligendi incidunt iusto natus architecto ratione 
                amet quasi quisquam vero quibusdam et ut, nesciunt corrupti 
                eius accusamus atque dignissimos quos exercitationem.
            </p>
            <p class="content">
                Lorem ipsum dolor, sit amet consectetur adipisicing elit. 
                Sapiente eligendi incidunt iusto natus architecto ratione 
                amet quasi quisquam vero quibusdam et ut, nesciunt corrupti 
                eius accusamus atque dignissimos quos exercitationem.
            </p>
        </main>
        <?php include 'includes/footer.php'; ?>
