<ul>
    <li><a href="index.php" class="active">Home</a></li>
    <li><a href="about.php">About</a></li>
    <li><a href="gallery.php">Gallery</a></li>
    <li><a href="service.php">Service</a></li>
    <li><a href="contact.php">Contact</a></li>
</ul>